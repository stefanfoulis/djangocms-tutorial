The solution to https://docs.djangoproject.com/en/dev/intro/tutorial01/

This zip is based on:

	Dir			django-poll-app/polls
	Commit #	ee4d0f610e3ad87a72e5dbf92da68d9120b34735