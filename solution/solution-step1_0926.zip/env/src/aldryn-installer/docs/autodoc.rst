.. automodule:: aldryn_installer.config
    :members:
    :undoc-members:

.. automodule:: aldryn_installer.django
    :members:
    :undoc-members:

.. automodule:: aldryn_installer.install
    :members:
    :undoc-members:

.. automodule:: aldryn_installer.main
    :members:
    :undoc-members:
